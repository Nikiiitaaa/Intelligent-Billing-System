from flask import Flask, render_template, request, redirect, url_for, jsonify
import sqlite3
import json

app = Flask(__name__)

# Define a custom Jinja2 filter for generating serial numbers
@app.template_filter('serial_number')
def serial_number_filter(value, start=1):
    return list(range(start, start + len(value)))


# Function to insert products
def insert_products():
    products_data = [
        (1, 'Colgate', 50),
        (2, 'Kitkat', 10),
        (3, 'Lays-Chips', 10),
        (4, 'Maggie', 15),
        (5, 'Parle-G', 10),
        (6, 'Ponds', 45),
        (7, 'Rin-Soap', 10),
        (8, 'Sprite', 20)
    ]
    product_names = [product[1] for product in products_data]
    return product_names

# Route to serve the product names for the "Add New Product" dropdown
@app.route('/get_product_names')
def get_product_names():
    product_names = insert_products()
    return jsonify(product_names)

# Route to display orders
@app.route('/')
def orders():
    conn = sqlite3.connect('data.db')
    cursor = conn.cursor()

    # Fetch orders from the database
    cursor.execute("SELECT * FROM orders")
    orders = cursor.fetchall()


    # Calculate total price
    final_price = sum(order[3] for order in orders)

    conn.close()
    return render_template('orders.html', orders=orders, final_price=final_price)

# Route to handle editing orders
@app.route('/edit_order', methods=['POST'])
def edit_order():
    order_id = request.form['order_id']
    quantity = int(request.form['quantity'])

    conn = sqlite3.connect('data.db')
    cursor = conn.cursor()

    # Fetch unit price of the product
    cursor.execute("SELECT total_price, quantity FROM orders WHERE order_id = ?", (order_id,))
    total_price, original_quantity = cursor.fetchone()
    unit_price = total_price / original_quantity

    # Update the quantity in the database
    cursor.execute("UPDATE orders SET quantity = ? WHERE order_id = ?", (quantity, order_id))
    conn.commit()

    # Calculate the new total price
    total_price = quantity * unit_price

    # Update the total price in the database
    cursor.execute("UPDATE orders SET total_price = ? WHERE order_id = ?", (total_price, order_id))
    conn.commit()

    conn.close()
    return redirect(url_for('orders'))

# Route to add a new product
@app.route('/add_product', methods=['POST'])
def add_product():
    product_name = request.form['product_name']
    quantity = int(request.form['quantity'])
    price = float(request.form['price'])

    conn = sqlite3.connect('data.db')
    cursor = conn.cursor()

    # Check if the product already exists in the orders table
    cursor.execute("SELECT * FROM orders WHERE product_name = ?", (product_name,))
    existing_product = cursor.fetchone()

    if existing_product:
        # If the product exists, increment the quantity
        new_quantity = existing_product[2] + quantity
        # Update the total price
        total_price = new_quantity * price
        cursor.execute("UPDATE orders SET quantity = ?, total_price = ? WHERE product_name = ?", (new_quantity, total_price, product_name))
    else:
        # If the product does not exist, insert a new entry
        cursor.execute("INSERT INTO orders (product_name, quantity, total_price, order_date) VALUES (?, ?, ?, CURRENT_TIMESTAMP)", (product_name, quantity, quantity * price))

    conn.commit()
    conn.close()
    return redirect(url_for('orders'))

   # Route to delete an order
@app.route('/delete_order', methods=['POST'])
def delete_order():
    order_id = request.form['order_id']

    conn = sqlite3.connect('data.db')
    cursor = conn.cursor()

    # Fetch the total price of the order to be deleted
    cursor.execute("SELECT total_price FROM orders WHERE order_id = ?", (order_id,))
    total_price = cursor.fetchone()[0]

    # Delete the order from the database
    cursor.execute("DELETE FROM orders WHERE order_id = ?", (order_id,))
    conn.commit()

    # Update the total price
    cursor.execute("SELECT SUM(total_price) FROM orders")
    new_total_price = cursor.fetchone()[0]

    if new_total_price is None:
        new_total_price = 0

    conn.close()
    return redirect(url_for('orders'))

if __name__ == '__main__':
    app.run(debug=True)
