# app.py

from flask import Flask, render_template, request, redirect, url_for
from datetime import datetime
import sqlite3

app = Flask(__name__)

# Function to create a connection to the SQLite database
def create_connection():
    conn = sqlite3.connect('data.db')
    return conn

# Route for the invoice page
@app.route('/')
def invoice():
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM orders")
    orders = cursor.fetchall()
    
    # Fetch customer details from the database (assuming only one customer for simplicity)
    cursor.execute("SELECT * FROM customers LIMIT 1")
    customer = cursor.fetchone()
    customer_name = customer[0]
    customer_phone = customer[1]

    # Calculate total price
    total_price = sum(order[3] for order in orders)

    # Calculate GST rate and total with GST
    gst_rate = 18  # Assuming GST rate is 18%
    total_with_gst = total_price + (total_price * (gst_rate / 100))

    # Get current date and time
    current_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor.close()
    conn.close()

    return render_template('invoice.html', orders=orders, customer_name=customer_name, customer_phone=customer_phone, total_price=total_price, gst_rate=gst_rate, total_with_gst=total_with_gst, current_date=current_date)


@app.route('/pay', methods=['POST'])
def pay():
    # Logic for payment
    return redirect(url_for('success'))

@app.route('/success')
def success():
    return "Payment successful!"

if __name__ == '__main__':
    app.run(debug=True)
